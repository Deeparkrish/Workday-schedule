A todo app that lets the user create and delete todos

Bootstrap, jQuery
