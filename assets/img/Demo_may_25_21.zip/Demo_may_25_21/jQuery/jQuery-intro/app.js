$(document).ready(function () {
  //text

  var header = $("#header-text");

  header.text("Hello im change");

  //html
  $(".container1").html("<h1>Wow</h1>");
  $(".container1").html("<p>Cool</p>");
  $(".container1").html("<p>Overwritten</p>");

  //append
  var con2 = $(".container2");
  var header1 = $("<h1>");
  header1.text("thing");

  con2.attr("class", "red-text");
  console.log(con2.attr("class"));

  con2.append(header1);
  con2.append("<p>Hello from paragraph</p>");

  var input = "classroom";
  con2.append(`<p class='pBtn'>Hello from ${input}</p>`);

  $("#btn").on("click", function () {
    console.log($(this).attr("id"));
  });

  $(".pBtn").on("click", function () {
    console.log("yes???");
  });
});
